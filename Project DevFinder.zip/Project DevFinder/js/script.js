let themeBtn = document.querySelector(".theme-btn"),
  searchBtn = document.querySelector(".search"),
  input = document.querySelector(".input"),
  avatarUrl = document.querySelector(".avatar-url"),
  user = document.querySelector(".user"),
  link = document.querySelector(".link"),
  privacy = document.querySelector(".privacy"),
  bio = document.querySelector(".bio"),
  repository = document.querySelector(".repository"),
  follower = document.querySelector(".follower"),
  follow = document.querySelector(".follow"),
  area = document.querySelector(".area"),
  gthLink = document.querySelector(".gth-link"),
  twitter = document.querySelector(".twitter");
gitHub = document.querySelector(".github");



let getmode = localStorage.getItem('mode');
if (getmode && getmode === 'dark') {
  document.body.classList.toggle("dark");
} else {
  document.body.classList.toggle("light");
}


themeBtn.addEventListener("click", () => {
  if (document.body.classList.toggle("dark")) {
    themeBtn.innerHTML = `LIGHT<img src="./images/icon-sun.svg" class="night-img">`;
    return localStorage.setItem('mode',"dark")
  } else {
    themeBtn.innerHTML = `DARK <img src="./images/icon-moon.svg" class="night-img">`;
    localStorage.setItem('mode','light')
  }
});

let userName = "";
let apiUrl = "https://api.github.com/users";

searchBtn.addEventListener("click", searchUser);
document.body.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    searchUser();
  }
});

function searchUser() {
  userName = input.value;
  fetch(apiUrl + `/${userName}`)
    .then((res) => res.json())
    .then((data) => {
      console.log(data);
      avatarUrl.setAttribute("src", data.avatar_url);
      user.textContent = data.login;
      link.textContent = data.name;
      bio.textContent = data.bio;
      if (data.bio === "") {
        bio.textContent = "There is no bio";
      }
      privacy.textContent =
        "Joined " + data.created_at.slice(0, 10).split("-").reverse();
      repository.textContent = data.public_repos;
      follower.textContent = data.followers;
      follow.textContent = data.following;
      area.innerHTML = `<img src="./images/icon-location.svg">` + data.location;
      gthLink.innerHTML = `<img src="./images/002-url.svg">` + data.blog;
      twitter.innerHTML =
        `<img src="./images/icon-twitter.svg">` + data.twitter_username;
    });
}
